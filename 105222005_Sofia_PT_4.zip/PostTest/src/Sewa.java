public class Sewa {
    Pelanggan pelanggan;
    Mobil mobil;
    int lamaSewa;
    double totalBiaya;
    boolean sukses;
    
    // Konstruktor Parameter
    Sewa(Pelanggan pelanggan, Mobil mobil, int lamaSewa) {
        this.pelanggan = pelanggan;
        this.mobil = mobil;
        this.lamaSewa = lamaSewa;
        prosesSewa();
    }
    
    // Menghitung total biaya berdasarkan harga sewa mobil dan lama sewa
    void prosesSewa() {
        if (mobil.tersedia) {
            totalBiaya = mobil.hargaSewaPerHari * lamaSewa;
            totalBiaya = Utility.hitungDiskon(totalBiaya, lamaSewa);
            mobil.ubahStatus(false);
            sukses = true;
        } else {
            sukses = false;
        }
    }
    
    // Menampilkan struk penyewaan
    void tampilkanStruk() {
        System.out.println("\n========== STRUK PENYEWAAN ==========");

        pelanggan.tampilkanInfo();
        mobil.tampilkanInfo();

        System.out.println("Lama Sewa   : " + lamaSewa + " hari");
        System.out.println("Total Biaya : " + Utility.formatMataUang(totalBiaya));
        System.out.println("Status      : " + (sukses ? "Transaksi Berhasil" : "Transaksi Gagal"));
        System.out.println("======================================");
    }
}
