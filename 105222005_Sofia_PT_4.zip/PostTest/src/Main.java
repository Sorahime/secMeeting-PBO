public class Main {
    public static void main(String[] args) {
    
        // Membuat objek dari kelas Mobil
        Mobil mobil1 = new Mobil("B 1122 XYZ", "Lamborghini Aventador", 5000000, true);
        Mobil mobil2 = new Mobil("D 3344 ABC", "Ferrari 488 GTB", 5500000, true);
        Mobil mobil3 = new Mobil("L 5566 DEF", "Porsche 911 Turbo S", 4800000, true);
        Mobil mobil4 = new Mobil("F 7788 GHI", "McLaren 720S", 5300000, true);
        Mobil mobil5 = new Mobil("T 9900 JKL", "Aston Martin DBS Superleggera", 5200000, true);
    
        // Menampilkan daftar mobil
        System.out.println("==== DAFTAR MOBIL SPORT YANG TERSEDIA ====");
        mobil1.tampilkanInfo();
        mobil2.tampilkanInfo();
        mobil3.tampilkanInfo();
        mobil4.tampilkanInfo();
        mobil5.tampilkanInfo();
    
        // Membuat objek dari kelas pelanggan
        Pelanggan pelanggan1 = new Pelanggan("Anastasia", "3210987654321", "081234567890");
        Pelanggan pelanggan2 = new Pelanggan("Zhenya", "3211234567890", "089876543210");
    
        // Melakukan transaksi penyewaan
        Sewa transaksi1 = new Sewa(pelanggan1, mobil2, 7);
        transaksi1.tampilkanStruk();

        Sewa transaksi2 = new Sewa(pelanggan2, mobil4, 3);
        transaksi2.tampilkanStruk();
    
        // Menampilkan daftar mobil setelah penyewaan
        System.out.println("==== DAFTAR MOBIL TERBARU ====");
        mobil1.tampilkanInfo();
        mobil2.tampilkanInfo();
        mobil3.tampilkanInfo();
        mobil4.tampilkanInfo();
        mobil5.tampilkanInfo();

    }
}
