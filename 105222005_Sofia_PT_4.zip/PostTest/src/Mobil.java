public class Mobil {
    String nomorPlat;
    String merek;
    double hargaSewaPerHari;
    boolean tersedia;

    // Konstruktor default
    Mobil() {
        this("Tidak diketahui", "Tidak diketahui", 0.0, true);
    }

    // Konstruktor Parameter
    Mobil(String nomorPlat, String merek, double hargaSewaPerHari, boolean tersedia) {
        this.nomorPlat = nomorPlat;
        this.merek = merek;
        this.hargaSewaPerHari = hargaSewaPerHari;
        this.tersedia = tersedia;
    }

    // Informasi mobil (Menampilkan daftar mobil yang tersedia)
    void tampilkanInfo() {
        System.out.println("Nomor Plat          : " + nomorPlat);
        System.out.println("Merek               : " + merek);
        System.out.println("Harga Sewa per Hari : " + Utility.formatMataUang(hargaSewaPerHari));
        System.out.println("Status              : " + (tersedia ? "Tersedia" : "Tidak Tersedia"));
        System.out.println("\n");
    }

    // Status ketersediaan
    void ubahStatus(boolean status) {
        this.tersedia = status;
    }
}
