public class Utility {
    // Menghitung diskon jika lama sewa lebih dari 5 hari
    static double hitungDiskon(double total, int lamaSewa) {
        if (lamaSewa > 5) {
            return total * 0.10; // Diskon 10%
        }
        return total;
    }
    
    // Mengonversi angka ke dalam format mata uang yang mudah dibaca
    static String formatMataUang(double jumlah) {
        return String.format("Rp%,.2f", jumlah);
    } 
}
