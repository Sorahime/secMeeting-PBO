public class Transaksi {
    //Atribut
    String idTransaksi;
    Pelanggan pelanggan;
    Produk produk;
    int jumlahBeli;
    double totalHarga;
    
    //Konstruktor
    Transaksi (String idTransaksi, Pelanggan pelanggan, Produk produk, int jumlahBeli) {
        this.idTransaksi = idTransaksi;
        this.pelanggan = pelanggan;
        this.produk = produk;
        this.jumlahBeli = jumlahBeli;
        this.totalHarga = produk.harga * jumlahBeli;
    }
    
    //Method
    public void prosesTransaksi() {
        if (pelanggan.saldo >= totalHarga && produk.stok >= jumlahBeli) {
            pelanggan.kurangiSaldo(totalHarga);
            produk.kurangiStok(jumlahBeli);
            System.out.println("Transaksi berhasil");
        } else {
            System.out.println("Transaksi gagal, saldo tidak mencukupi");
        }
    }

    public void tampilkanDetailTransaksi() {
        System.out.println("ID Transaksi   : " + idTransaksi);
        System.out.println("Nama Pelanggan : " + pelanggan.nama);
        System.out.println("Nama Produk    : " + produk.namaProduk);
        System.out.println("Jumlah Beli    : " + jumlahBeli);
        System.out.println("Total Harga    : " + totalHarga);
        System.out.println();
    }
}
