public class Produk {
    
    //Atribut
    String kodeProduk;
    String namaProduk;
    double harga;
    int stok;

    //Konstruktor
    Produk (String kodeProduk, String namaProduk, double harga, int stok) {
        this.kodeProduk = kodeProduk;
        this.namaProduk = namaProduk;
        this.harga = harga;
        this.stok = stok;
    }

    //Method
    public void tampilkanInfoProduk() {
        System.out.println("Kode Produk : " + kodeProduk);
        System.out.println("Nama Produk : " + namaProduk);
        System.out.println("Harga       : " + harga);
        System.out.println("Stok        : " + stok);
        System.out.println();
    }

    public void kurangiStok(int jumlah) {
        stok = stok - jumlah;
    }
}
