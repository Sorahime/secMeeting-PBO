public class Pelanggan {
    
    //Atribut
    String idPelanggan;
    String nama;
    String email;
    double saldo;
    
    //Konstruktor
    public Pelanggan (String idPelanggan, String nama, String email, double saldo) {
        this.idPelanggan = idPelanggan;
        this.nama = nama;
        this.email = email;
        this.saldo = saldo;
    }
    
    //Method
    public void tampilkanInfoPelanggan() {
        System.out.println("ID Pelanggan : " + idPelanggan);
        System.out.println("Nama         : " + nama);
        System.out.println("Email        : " + email);
        System.out.println("Saldo        : " + saldo);
        System.out.println();
    }
    
    public void topUpSaldo(double jumlah) {
        saldo = saldo + jumlah;
    }

    public void kurangiSaldo(double jumlah) {
        saldo = saldo - jumlah;
    }
}
