public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("=== SISTEM MANAJEMEN TOKO ONLINE ===");
        System.out.println("\n============ Info Produk ============");

        Produk produk1 = new Produk("MV001", "Black Vandetta Watch", 2500000, 10);
        produk1.tampilkanInfoProduk();

        Produk produk2 = new Produk("MV002", "Godfather Colegne", 1200000, 15);
        produk2.tampilkanInfoProduk();

        Produk produk3 = new Produk("MV003", "Mafia Noir Jacket", 7800000, 7);
        produk3.tampilkanInfoProduk();

        System.out.println("=====================================");
        System.out.println("\n======== Identitas Pelanggan ========");

        Pelanggan pelanggan1 = new Pelanggan ("C001", "Adrian Salvatore", "adrian@gmail.com", 6000000.0);
        pelanggan1.tampilkanInfoPelanggan();

        Pelanggan pelanggan2 = new Pelanggan ("C002", "Vincent deLuca", "vinden.l@gmail.com", 8800000.0);
        pelanggan2.tampilkanInfoPelanggan(); 

        Pelanggan pelanggan3 = new Pelanggan ("C003", "Isabella Marino", "isbl@gmail.com", 2900000.0);
        pelanggan3.tampilkanInfoPelanggan();

        System.out.println("====================================");
        System.out.println("\n========= Proses Transaksi =========");
        Transaksi transaksi1 = new Transaksi("T001", pelanggan1, produk1, 2);
        transaksi1.prosesTransaksi();
        transaksi1.tampilkanDetailTransaksi();

        Transaksi transaksi2 = new Transaksi("T002", pelanggan3, produk3,3);
        transaksi2.prosesTransaksi();
        transaksi2.tampilkanDetailTransaksi();


    }
}
