package aktivitasPraktikum;

class Animal {
    public void makeSound() {
        System.out.println("Animal sound");
    }
}

class Mammal extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Mammal sound");
    }

}

class reptile  extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Reptile sound");
    }
}

class Dog extends Mammal {
    @Override
    public void makeSound() {
        System.out.println("Bark");
    }
}

public class AP1 {
    public static void main(String[] args) {
        Animal animal1 = new Animal();
        Mammal mammal1 = new Mammal();
        reptile reptile1 = new reptile();

        Dog dog1 = new Dog();
        System.out.println(mammal1 instanceof Animal); // true
        System.out.println(dog1 instanceof Animal); // true
        System.out.println(dog1 instanceof Mammal); // true
        //System.out.println(dog1 instanceof reptile); // false

        Animal animal2 = new Mammal();
        //Dog dog2 = (Dog) animal2; // ClassCastException ERROR
        if (animal2 instanceof Dog) {
           // Dog dog2 = (Dog) animal2; // Safe cast
            System.out.println("Objek berhasil dibuat");
        } else {
            System.out.println("Gagal membuat objek");
        }

        animal1.makeSound(); // Animal sound
        mammal1.makeSound(); // Mammal sound
        reptile1.makeSound(); // Reptile sound
    }
}