package aktivitasPraktikum;

class Engine {
    void start() {
        System.out.println("Mesin menyala");
    }
}

class Car {
    Engine engine = new Engine();
    void drive() {
        engine.start();
        System.out.println("Mobil berjalan");
    }
}

public class AP2 {
    public static void main(String[] args) {
        Car car1 = new Car();
        car1.drive();
    }
}
