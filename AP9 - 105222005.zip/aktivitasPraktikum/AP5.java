package aktivitasPraktikum;

class Kamar {
    String tipe;

    public Kamar(String tipe) {
        this.tipe = tipe;
    }

    void info(){
        System.out.println("Tipe Kamar: " + tipe);
    }
}

class Rumah {
    private Kamar kamar;

    Rumah() {
        kamar = new Kamar ("Kamar Mandi");
    }

    void lihatKamar() {
        kamar.info();
    }
}

public class AP5 {
    public static void main(String[] args) {
        Rumah rumah = new Rumah();
        rumah.lihatKamar();
    }
}