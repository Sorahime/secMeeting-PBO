package aktivitasPraktikum;

class Animal {
    void makeSound() {
        System.out.println("Aku Denger Suara");
    }
}

class Dog extends Animal {
    void soundDog() {
        System.out.println("Bark");
    }
}

class Pig extends Animal {
    void soundPig() {
        System.out.println("Oink");
    }
}

public class AP3 {
    public static void main(String[] args) {
        Dog dog1 = new Dog();
        dog1.makeSound();
        dog1.soundDog();

        Pig pig1 = new Pig();
        pig1.makeSound();
        pig1.soundPig();
    }
    
}
