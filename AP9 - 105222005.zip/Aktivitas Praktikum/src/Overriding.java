class Animal {
    public void suara(){
        System.out.println ("Cetak Suara");
    }

    public void makan(String lauk){
        System.out.println("Hewan ini makan " + lauk);
    } 
}

class Dog extends Animal {
    @Override
    public void suara(){
        System.out.println ("Guk Guk Guk");
    }

    public void makan (String lauk, String minuman){
        System.out.println("Hewan ini makan " + lauk + " dan minum " + minuman);
    }
}

public class Overriding {
    public static void main(String[] args) {
        Animal a = new Animal();
        a.suara();

        Animal d = new Dog();
        d.suara();
        d.makan ("Ayam goreng");

        Dog dg = new Dog();
        dg.makan("Ayam Goreng", "Aqua");
    }
}