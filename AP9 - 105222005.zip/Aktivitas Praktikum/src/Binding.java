class Animal {
    static void Suara(){
        System.out.println ("Cetak Suara");
    }

    void makan () {
        System.out.println("Hewan ini makan");
    }
} 

class Dog extends Animal {
    @Override
    void makan(){
        System.out.println("Anjing makan daging");
    }
}

public class Binding {
    public static void main(String[] args) {
        Animal a = new Animal(); 
        //a.Suara();
        //a.makan();

        Animal.Suara(); // Static (gaperlu buat objek dari class Animal)
        a.makan(); // Binding (gaperlu buat objek dari class Animal)

        Animal b = new Dog();
        b.makan(); // Dynamic Binding (gaperlu buat objek dari class Dog)
    }
}

