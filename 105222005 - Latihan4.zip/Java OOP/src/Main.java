public class Main {
    public static void main(String[] args) {
        //  Membuat objek dari kelas Mahasiswa  
        //Mahasiswa mhs1 = new Mahasiswa ("Abel", "12345", "Teknik Informatika");

        Mahasiswa mhs1 = new Mahasiswa();

        mhs1.nama = "Abel";
        mhs1.nim = "12345";
        mhs1.jurusan = "Teknik Informatika";
        mhs1.belajar();

        Mahasiswa.kuliah();
        System.out.println(Mahasiswa.angkatan);

        // Mencetak nama, nim, jurusan dari objek mhs1
        System.out.println(mhs1.nama); 
        System.out.println(mhs1.nim); 
        System.out.println(mhs1.jurusan); 

        mhs1.nama = "Cesare";
        System.out.println(mhs1.nama);

        mhs1.belajar();
        mhs1.belajar("Calisto");
        
        //  Membuat objek dari kelas Mahasiswa 
        //Mahasiswa mhs2 = new Mahasiswa("Dmitriv", "54321", "Teknik Mesin");

        Mahasiswa mhs2 = new Mahasiswa(mhs1);

        // mhs2.nama = "Dmitriv";
        // mhs2.nim = "54321";
        // mhs2.jurusan = "Teknik Mesin";
        // mhs2.belajar();

        // Mencetak nama, nim, jurusan dari objek mhs2
        System.out.println(mhs2.nama); 
        System.out.println(mhs2.nim); 
        System.out.println(mhs2.jurusan); 
        mhs2.belajar();
    }
}