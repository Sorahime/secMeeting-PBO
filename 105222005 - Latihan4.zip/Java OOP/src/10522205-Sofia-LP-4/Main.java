public class Main {
    public static void main(String[] args) {
        
        // Membuat objek dari kelas Mahasiswa  
        Mahasiswa mhs1 = new Mahasiswa ("Sofia", "10522205", "Ilmu Komputer");
    }
}