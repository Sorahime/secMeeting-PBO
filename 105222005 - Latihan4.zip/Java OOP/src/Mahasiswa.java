public class Mahasiswa {

    //Atribut
    String nama;
    String nim;
    String jurusan;
    boolean isLulus = false;
    static int angkatan = 2020;

    //Konstruktor
    //Mahasiswa(String nama, String nim, String jurusan) {
     //   this.nama = nama;
    //    this.nim = nim;
    //    this.jurusan = jurusan;
    //}

    //Konstruktor tanpa parameter (default)
    //Mahasiswa (){
    //    this("no name", "00000", "no jurusan");
    //}
    

    //Konstraktor copy
    //Mahasiswa(Mahasiswa m) {
     //   this.nama = m.nama;
     //   this.nim = m.nim;
     //   this.jurusan = m.jurusan;
    //}

    //Method
    void belajar() {
        System.out.println(this.nama + " sedang belajar di kelas");
    }

    //Method Overloading
    void belajar(String nama) {
        System.out.println(nama + " sedang belajar ");
    }

    //Getter
    String getNama() {
        return nama;
    }

    //Method Static
    static void kuliah(){
        System.out.println("Mahasiswa sedang kuliah");
    }

    //Inner Class
    class Dalam {
        void test() {
            System.out.println("ini adalah inner class");
        }
    }



}