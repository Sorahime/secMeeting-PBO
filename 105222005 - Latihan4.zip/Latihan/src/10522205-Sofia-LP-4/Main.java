public class Main {
    public static void main(String[] args) {
        // Membuat objek Mahasiswa
        Mahasiswa m1 = new Mahasiswa("Sora", "2201001", "Informatika", 3.5);
        Mahasiswa m2 = new Mahasiswa("Sofia", "2201002", "Sastra", 2.8);

        // Menampilkan informasi mahasiswa
        System.out.println("=== Data Mahasiswa 1 ===");
        m1.tampilkanInfo():

        System.out.println("\n=== Data Mahasiswa 2 ===");
        m2.tampilkanInfo();
    }
}
