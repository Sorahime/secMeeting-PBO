public class Mahasiswa {

    //Atribut
    String nama;
    String nim;
    String jurusan;
    double ipk;


    //Konstruktor
    Mahasiswa (String nama, String nim, String jurusan, double ipk) {
        this.nama = nama;
        this.nim = nim;
        this.jurusan = jurusan;
        this.ipk = ipk;
    }

    //Method
    public boolean isLulus() {
        return this.ipk >= 3.0;
    }

    public void tampilkanInfo() {
        System.out.println("Nama    : " + nama);
        System.out.println("NIM     : " + nim);
        System.out.println("Jurusan : " + jurusan);
        System.out.println("IPK     : " + ipk);
        System.out.println("Lulus   : " + isLulus());
    }

}