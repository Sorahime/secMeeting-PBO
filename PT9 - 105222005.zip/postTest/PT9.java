package postTest;
import java.time.LocalDate;

class Vehicle {
    void startEngineMobil(){
        System.out.println("Mesin mobil nyala");
    }

    void startEngineMotor(){
        System.out.println("Mesin motor nyala");
    } 
}


class Driver {
    String name;
    Vehicle vehicle;
    License license;

    Driver(String name, Vehicle vehicle, License license) {
        this.name = name;
        this.vehicle = vehicle;
        this.license = license;
    } 

    void drive(Vehicle vehicle) {
        if (vehicle instanceof Vehicle) {
            System.out.println("Kendaraan adalah mobil");
        } else {
            System.out.println("Kendaraan adalah motor");
        } 
            System.out.println("Kendaraan siap digunakan");
    }

    void showLicense (){
        System.out.println("Nama Pengemudi : " + name);
        System.out.println("Tipe Kendaraan : " + vehicle.getClass().getSimpleName());
        license.printInfo();
        System.out.println();

    }
}

class License {
    String licenseNumber;
    LocalDate validUntil;

    License(String licenseNumber) {
        this.licenseNumber = licenseNumber;
        this.validUntil = LocalDate.now().plusYears(5);
    }

    void printInfo() {
        System.out.println("Nomor Lisensi  : " + licenseNumber);
        System.out.println("Berlaku sampai : " + validUntil);
        System.out.println();
    }
}

public class PT9 {
    public static void main(String[] args) {
        Vehicle car = new Vehicle();
        Vehicle motor = new Vehicle();
        License carLicense = new License("123456789");
        License motorLicense = new License("987654321");

        Driver driver1 = new Driver("Sora", car, carLicense);
        Driver driver2 = new Driver("Sofia", motor, motorLicense);

        driver1.drive(car);
        car.startEngineMobil();
        driver1.showLicense();

        driver2.drive(motor);
        motor.startEngineMotor();
        driver2.showLicense();

    }
}
