class Employee {
    void calculateSalary(){
        System.out.println("Calculating salary...");
    }

    void calculateSalary(boolean withBonus){
        System.out.println("Calculating salary with bonus...");
        System.out.println();
    }
}

class SoftwareEngineer extends Employee {
    void calculateSalary(){
        System.out.println("Calculating salary for Software Engineer...");
    }

    void calculateSalary(boolean withBonus){
        System.out.println("Calculating salary for Software Engineer with bonus...");
        System.out.println();
    }
}

class DataScientist extends Employee {
    void calculateSalary(){
        System.out.println("Calculating salary for Data Scientist...");
    }

    void calculateSalary(boolean withBonus){
        System.out.println("Calculating salary for Data Scientist with bonus...");
        System.out.println();
    }
}

class Intern extends Employee {
    void calculateSalary(){
        System.out.println("Calculating salary for Intern...");
    }

    void calculateSalary(boolean withBonus){
        System.out.println("Calculating salary for Intern with bonus...");
        System.out.println();
    }
}

public class Manajemen {
    public static void main(String[] args) throws Exception {
        //Menyimpan array/list Employee[]
        Employee[] employees = new Employee[3];
        employees[0] = new SoftwareEngineer();
        employees[1] = new DataScientist();
        employees[2] = new Intern();

        //Memanggil method calculateSalary() untuk setiap objek Employee secara polymorphic
        for (Employee employee : employees) {
            employee.calculateSalary();
            employee.calculateSalary(true);
        }

        //Memanggil calculateSalary() secara langsung dari objek
        SoftwareEngineer se = new SoftwareEngineer();
        se.calculateSalary();
        se.calculateSalary(true);

        DataScientist ds = new DataScientist();
        ds.calculateSalary();
        ds.calculateSalary(true);

        Intern intern = new Intern();
        intern.calculateSalary();
        intern.calculateSalary(true);
    }
}
