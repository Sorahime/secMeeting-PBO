package Coba;

public class Smartphone implements Gadget {

    @Override
    public void hidupkan() {
        System.out.println("Smartphone dinyalakan.");
    }
    
}
