package Coba;

public class Main {
    public static void main(String[] args) {
        Gadget gadget = new Smartphone();
        gadget.hidupkan();
        gadget.cekBaterai();
        Gadget.info();

        Smartphone smartphone = new Smartphone();
        smartphone.hidupkan();
        smartphone.cekBaterai();
    }
}
