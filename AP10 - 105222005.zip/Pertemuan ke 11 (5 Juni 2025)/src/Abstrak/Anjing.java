package Abstrak;

public class Anjing extends Hewan {
     Anjing(String nama) {
        super(nama);
    }

    @Override
    void suara() {
        System.out.println(nama + " woof woof.");
    }
}
