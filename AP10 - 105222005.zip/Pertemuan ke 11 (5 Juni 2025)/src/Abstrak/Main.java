package Abstrak;

public class Main {
    public static void main(String[] args) throws Exception {
        Hewan kucing = new Kucing("Shiro");
        kucing.makan();
        kucing.suara();

        Kucing k = new Kucing("Kuro");
        k.makan();
        k.suara();

        Hewan anjing = new Anjing("Sparta");
        anjing.makan();
        anjing.suara();

        Anjing a = new Anjing("Rex");
        a.makan();
        a.suara();
    }
}
