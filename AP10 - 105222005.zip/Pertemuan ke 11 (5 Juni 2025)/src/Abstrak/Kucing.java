package Abstrak;

public class Kucing extends Hewan {

    Kucing(String nama) {
        super(nama);
    }

    @Override
    void suara() {
        System.out.println(nama + " meong.");
    }
}

