package antarMuka;

public interface Pabrik {
    void produksiKendaraan();
}
