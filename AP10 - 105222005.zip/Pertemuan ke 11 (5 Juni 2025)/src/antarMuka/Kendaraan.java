package antarMuka;

public interface Kendaraan {
    public void nyalakanMesin();

    public void matikanMesin();
}
