package antarMuka;

public class Mobil extends Pemilik implements Kendaraan, Pabrik {

    Mobil (String nama) {
        super(nama);
    }

    @Override
    public void nyalakanMesin() {
        System.out.println("Mesin mobil dinyalakan.");
    }

    @Override
    public void matikanMesin() {
        System.out.println("Mesin mobil dimatikan.");
    }

    @Override
    public void produksiKendaraan() {
        System.out.println("Produksi mobil.");
    }

    @Override
    public void pemilikKendaraan() {
        System.out.println("Pemilik mobil: " + nama);
    }
}