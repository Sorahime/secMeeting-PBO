package antarMuka;

public class Main {
    public static void main(String[] args) {

        Mobil mobil = new Mobil("Budi");
        mobil.pemilikKendaraan();
        mobil.nyalakanMesin();
        mobil.matikanMesin();
        mobil.produksiKendaraan();
    }    
}
