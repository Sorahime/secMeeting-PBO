package com_university_model;

public class Main {
    public static void main(String[] args) throws Exception {
        Student[] students = new Student[5];
        
        students[0] = new Student("105222001", "Alaric von Falkenstein", 19, 3.8);

        students[1] = new Student("105222002", "Katarina Eisnberg", 20, 3.6);
        students[2] = new Student("105222003", "Maximiliam von Adlerhof", 21, 3.7);
        students[3] = new Student("105222004", "Anneliese von Honheburg", 18, 3.9);
        students[4] = new Student("105222005", "Victor Eisenfaust", 22, 3.5);

        System.out.println("=== DATA MAHASISWA ===");
        System.out.println();
        for (Student student : students){
            System.out.println (
            "ID Mahasiswa   : " + student.getStudentId() + 
            "\nNama Mahasiswa : " + student.getName() +
            "\nUmur           : " + student.getAge() + 
            "\nGPA            : " + student.getGpa()
            );

        System.out.println();

        }
    }
}
