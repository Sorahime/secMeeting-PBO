package DataPekerja;

public class Main {
    public static void main(String[] args) throws Exception {
        Employee emp = new Employee("Alice", 25, 5000); //Tidak boleh menggunakan (.) pada salary karena
        emp.display();                                       // akan error sebab di java hanya bisa 5000
        emp.showSalary();                                   // secara langsung atau 5_000 agar berhasil.
    }   // sebelumnya emp.showsalary tidak ditambahkan, sehingga saat melakukan run program salary tidak muncul.                                             
}
