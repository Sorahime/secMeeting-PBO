package DataPekerja;

public class Person {
    private String name;
    private int age;
    
    public Person(String n, int a){
        name = n;
        age = a;
    }
    
    public void display(){
        System.out.println ("Name : " + name + ", Age : " + age);
    }
} // Masalah ada pada hilangnya penutup kurung kurawal miliki public void
  // yang seharusnya terletak sesudah deklarasi display.
