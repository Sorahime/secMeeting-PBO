package DataPekerja; //Jangan lupa menambahkan package agar bisa mengakses sesama didalam package

class Employee extends Person {
    
    private double salary;

    public Employee (String n, int a, double s) {
        super(n, a);  // Ini digunakan untuk mendeklarasikan konstruktor pada class person
        salary = s;  // jika tidak digunakan maka konstruktor pada kelas ini akan tetap error. 
                    // Menggunakan AI copilot untuk mencari tahu.
    }

    public void showSalary (){
        System.out.println ("Salary : " + salary); // Pada soal (,) berada disini sebelum diganti menjadi (;) 
                                                  // agar tidak error
    }
}