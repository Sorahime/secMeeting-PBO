import java.util.Scanner;
import universitas.*;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        ManajemenMahasiswa mm = new ManajemenMahasiswa();
        int pilihan;

        do {
            System.out.println("=== Menu ===");
            System.out.println("1. Tambah Mahasiswa");
            System.out.println("2. Tampilkan Semua Mahasiswa");
            System.out.println("3. Tampilkan IPK Tertinggi");
            System.out.println("4. Keluar");
            System.out.print("Pilih menu: ");
            pilihan = scanner.nextInt();
            scanner.nextLine(); // membersihkan newline

            switch (pilihan) {
                case 1:
                    System.out.print("Masukkan NIM  : ");
                    String nim = scanner.nextLine();
                    System.out.print("Masukkan Nama : ");
                    String nama = scanner.nextLine();
                    System.out.print("Masukkan Prodi: ");
                    String prodi = scanner.nextLine();
                    System.out.print("Masukkan IPK  : ");
                    double ipk = scanner.nextDouble();
                    Mahasiswa mhs = new Mahasiswa(nim, nama, prodi, ipk);
                    mm.tambahMahasiswa(mhs);
                    break;
                case 2:
                    mm.tampilkanSemua();
                    break;
                case 3:
                    mm.tampilkanIPKTertinggi();
                    break;
                case 4:
                    System.out.println("Keluar dari program.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 4);
        scanner.close();
    }
}
