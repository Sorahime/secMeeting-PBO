package universitas;

public class Mahasiswa {
    private String NIM;
    private String Nama;
    private String prodi;
    private double ipk;

    public Mahasiswa(String NIM, String Nama, String prodi, double ipk) {
        this.NIM = NIM;
        this.Nama = Nama;
        this.prodi = prodi;
        this.ipk = ipk;
    }
    
    public String getNIM() {
        return NIM;
    }

    public String getNama() {
        return Nama;
    }

    public String getProdi() {
        return prodi;
    }

    public double getIpk() {
        return ipk;
    }

    public void setNIM(String NIM) {
        this.NIM = NIM;
    }
    
    public void setNama(String Nama) {
        this.Nama = Nama;
    }
    
    public void setProdi(String prodi) {
            this.prodi = prodi;
    }

    public void setIpk(double ipk) {
        this.ipk = ipk;
    }

    public void tampilkanData() {
        System.out.println("=== Data Mahasiswa ===");
        System.out.println("NIM   : " + NIM);
        System.out.println("Nama  : " + Nama);
        System.out.println("Prodi : " + prodi);
        System.out.println("IPK   : " + ipk);
        System.out.println("=======================");
    }
              
}
