package universitas;
import java.util.ArrayList;

public class ManajemenMahasiswa {
   private ArrayList<Mahasiswa> daftarMahasiswa;

   public void tambahMahasiswa (Mahasiswa m){
        if (daftarMahasiswa == null) {
            daftarMahasiswa = new ArrayList<>();
        } daftarMahasiswa.add(m);
   }

   public void tampilkanSemua(){
        for (Mahasiswa m : daftarMahasiswa) {
            m.tampilkanData();
        }   
    }

    public void tampilkanIPKTertinggi(){
        if (daftarMahasiswa == null || daftarMahasiswa.isEmpty()) {
            System.out.println("Tidak ada data mahasiswa.");
        } else {
            Mahasiswa ipkTertinggi = daftarMahasiswa.get(0);
            for (Mahasiswa m : daftarMahasiswa) {
                if (m.getIpk() > ipkTertinggi.getIpk()) {
                    ipkTertinggi = m;
                }
            } System.out.println("Mahasiswa dengan IPK tertinggi:");
              ipkTertinggi.tampilkanData();
        }
    }
}
