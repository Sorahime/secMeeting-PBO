package kursusonline.service;

import kursusonline.model.*;
import java.util.*;

public class KursusService {
    private List<Kursus> daftarKursus = new ArrayList<>();

    public void tambahKursus(Kursus k) {
        daftarKursus.add(k);
    }

    public void tampilkanSemuaKursus() {
        for (Kursus k : daftarKursus)
            k.tampilkanDetailKursus();
    }

    public Kursus cariKursusBerdasarkanKode(String kode) {
        for (Kursus k : daftarKursus)
            if (k.getKode().equals(kode)) return k;
        return null;
    }

    public void tambahPesertaKeKursus(String kode, Peserta p) {
        Kursus k = cariKursusBerdasarkanKode(kode);
        if (k != null) {
            boolean success = k.tambahPeserta(p);
            if (!success) System.out.println("Gagal menambahkan peserta: " + p.getNama());
        }
    }
}
