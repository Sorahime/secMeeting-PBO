package kursusonline.model;

import java.time.LocalDate;

import java.time.LocalDateTime;

public class Sertifikat {
    private String sertifikatID;
    private String namaPeserta;
    private LocalDate tanggalTerbit;

    public Sertifikat(String sertifikatID, String namaPeserta, LocalDate tanggalTerbit) {
        this.sertifikatID = sertifikatID;
        this.namaPeserta = namaPeserta;
        this.tanggalTerbit = tanggalTerbit;
    }
}
