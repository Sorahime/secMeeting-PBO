package kursusonline.model;

public class Instruktur {
    private String instID;
    private String nama;
    private String spesialisasi;

    public Instruktur(String instID, String nama, String spesialisasi) {
        this.instID = instID;
        this.nama = nama;
        this.spesialisasi = spesialisasi;
    }

    // Getter
    public String getInstID() {
        return instID;
    }

    public String getNama() {
        return nama;
    }

    public String getSpesialisasi() {
        return spesialisasi;
    }

    // Setter
    public void setInstID(String instID) {
        this.instID = instID;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setSpesialisasi(String spesialisasi) {
        this.spesialisasi = spesialisasi;
    }
}

