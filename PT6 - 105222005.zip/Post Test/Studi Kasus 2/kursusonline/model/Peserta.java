public class Peserta {
    private String pesertaID;
    private String nama;
    private String email;
    private String noTelepon;
    private Sertifikat sertifikat;

    public Peserta(String pesertaID, String nama, String email, String noTelepon) {
        this.pesertaID = pesertaID;
        this.nama = nama;
        this.email = email;
        this.noTelepon = noTelepon;
    }

    //Getter
    public String getPesertaID() {
        return pesertaID;
    }

    public String getNama() {
        return nama;
    }

    public String getEmail() {
        return email;
    }

    public String getNoTelepon() {
        return noTelepon;
    }

    public String getSertifikat() {
        return sertifikat;
    }

    // Setter
    public void setPesertaID(String pesertaID) {
        this.pesertaID = pesertaID;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNoTelepon(String noTelepon) {
        this.noTelepon = noTelepon;
    }

    public void setSertifikat(String sertifikat) {
        this.sertifikat = sertifikat;
    }

    public boolean isEmailValid() {
        return email.endsWith("@gmail.com");
    }
}
