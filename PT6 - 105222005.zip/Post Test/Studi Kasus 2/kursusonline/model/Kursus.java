package kursusonline.model;
import java.util.*;

public class Kursus{
    private String kode, nama;
    private Instruktur instruktur;
    private ArrayList<Peserta> daftarPeserta = new ArrayList<>();
    private ArrayList<Materi> daftarMateri = new ArrayList<>();

    public Kursus(String kode, String nama, Instruktur instruktur) {
        this.kode = kode;
        this.nama = nama;
        this.instruktur = instruktur;
    }

    public String getKode() { return kode; }

    public void tambahMateri(Materi m) {
        daftarMateri.add(m);
    }

    public boolean tambahPeserta(Peserta p) {
        if (!p.isEmailValid()) return false;
        for (Peserta pes : daftarPeserta)
            if (pes.getId().equals(p.getId())) return false;
        daftarPeserta.add(p);
        return true;
    }

    public void tampilkanDetailKursus() {
        System.out.println("Kursus    : " + nama);
        System.out.println("Instruktur: " + instruktur.getNama());
        System.out.println("Materi  :");
        for (Materi m : daftarMateri) System.out.println("- " + m.getJudul());
        System.out.println("Peserta :");
        for (Peserta p : daftarPeserta) System.out.println("- " + p.getNama());
        System.out.println("----------------------------");
    }
}

