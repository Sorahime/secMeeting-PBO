import kursusonline.model.*;
import kursusonline.service.KursusService;

public class Main {
    public static void main(String[] args) {
        Instruktur i1 = new Instruktur("I1", "Sora", "Java");
        Instruktur i2 = new Instruktur("I2", "Sofia", "Web");

        Kursus k1 = new Kursus("K1", "Java Dasar", i1);
        Kursus k2 = new Kursus("K2", "Web Lanjut", i2);

        Peserta p1 = new Peserta("P1", "Abel", "Abie@gmail.com", "0812");
        Peserta p2 = new Peserta("P2", "Lysander", "raka@yahoo.com", "0813"); // invalid
        Peserta p3 = new Peserta("P3", "Maximiliam", "Mxmil@gmail.com", "0814");

        Materi m1 = new Materi("Pengenalan", "Dasar Java", 60);
        Materi m2 = new Materi("OOP", "OOP Java", 90);
        Materi m3 = new Materi("HTML", "Dasar Web", 45);

        k1.tambahMateri(m1);
        k1.tambahMateri(m2);
        k2.tambahMateri(m3);

        KursusService service = new KursusService();
        service.tambahKursus(k1);
        service.tambahKursus(k2);

        service.tambahPesertaKeKursus("K1", p1);
        service.tambahPesertaKeKursus("K1", p2); // gagal
        service.tambahPesertaKeKursus("K2", p3);

        service.tampilkanSemuaKursus();
    }
}
