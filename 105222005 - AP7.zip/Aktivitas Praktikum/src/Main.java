class Kendaraan { //Super class/Parent Class
    String merk;

    Kendaraan(){ // Constructor tanpa parameter
        System.out.println("Ini constructor Parent");
    }

    void jalan(){ // Method untuk menampilkan informasi kendaraan
        System.out.println("Kendaraan sedang berjalan");
    }
}

class Mobil extends Kendaraan { //Sub Class / Child Class
    String merk = "BMW";
    int kecepatan = 100;
    Mobil(){
        super(); // Memanggil constructor parent class
        System.out.println("Ini constructor Anak"); // Constructor anak class
    }

    void klakson(String merk){ // Parameter merk untuk menampung inputan dari user
        System.out.println("Klakson mobil " + super.merk + " berbunyi: Beep Beep!");
    }

    void printInfo(){ // Method untuk menampilkan informasi mobil
        System.out.println("Merk     : " + merk);
        System.out.println("Kecepatan: " + kecepatan + " km/jam");
        System.out.println("Kendaraan: " + super.merk);
        jalan(); // Memanggil method jalan dari parent class)
    }
}

public class Main {
    public static void main(String[] args) { // Main method
        Mobil mobil = new Mobil();
        mobil.jalan();
        mobil.klakson("Porsche");
        System.out.println(mobil.merk);
    }
}