class Transportasi {
    private String nama;
    private int jumlahKursi;
    private String tujuan;

    public Transportasi(String nama, int jumlahKursi, String tujuan) {
        this.nama = nama;
        this.jumlahKursi = jumlahKursi;
        this.tujuan = tujuan;
    }

    public String getNama() {
        return nama;
    }
    public int getJumlahKursi() {
        return jumlahKursi;
    }

   public String getTujuan() {
        return tujuan;
    }

    public void setJumlahKursi(int jumlahKursi) {
        this.jumlahKursi = jumlahKursi;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setTujuan(String tujuan) {
        this.tujuan = tujuan;
    }

    public double hitungHargaTiket() {
        return 100000;
    }
}

class Bus extends Transportasi {
    public Bus(String nama, int jumlahKursi, String tujuan) {
        super(nama, jumlahKursi, tujuan);
    }

    @Override
    public double hitungHargaTiket(){
        return super.hitungHargaTiket() * 0.10; 
    }

    public double hitungHargaTiket (String kelasLayanan){
        double base = hitungHargaTiket();
        if (kelasLayanan.equalsIgnoreCase("Ekonomi")) {
            return base * 1;
        } else if (kelasLayanan.equalsIgnoreCase("Bisnis")) {
            return base * 0.25;
        } else if (kelasLayanan.equalsIgnoreCase("VIP")) {
            return base * 0.50;
        } else {
            return base;
        }
    }
}

class Kereta extends Transportasi {
    public Kereta(String nama, int jumlahKursi, String tujuan) {
        super(nama, jumlahKursi, tujuan);
    }

    @Override
    public double hitungHargaTiket(){
        return super.hitungHargaTiket() * 0.20; 
    }

    public double hitungHargaTiket (String kelasLayanan){
        double base = hitungHargaTiket();
        if (kelasLayanan.equalsIgnoreCase("Ekonomi")) {
            return base * 1;
        } else if (kelasLayanan.equalsIgnoreCase("Bisnis")) {
            return base * 0.25;
        } else if (kelasLayanan.equalsIgnoreCase("VIP")) {
            return base * 0.50;
        } else {
            return base;
        }
    }
}

class Pesawat extends Transportasi {
    public Pesawat (String nama, int jumlahKursi, String tujuan) {
        super(nama, jumlahKursi, tujuan);
    }

    @Override
    public double hitungHargaTiket(){
        return super.hitungHargaTiket() * 0.50; 
    }

    public double hitungHargaTiket (String kelasLayanan){
        double base = hitungHargaTiket();
        if (kelasLayanan.equalsIgnoreCase("Ekonomi")) {
            return base * 1;
        } else if (kelasLayanan.equalsIgnoreCase("Bisnis")) {
            return base * 0.25;
        } else if (kelasLayanan.equalsIgnoreCase("VIP")) {
            return base * 0.50;
        } else {
            return base;
        }
    }
}

public class PesanTiket {
    public static void main(String[] args) throws Exception {
        Transportasi [] transportasi = new Transportasi[3];
        transportasi[0] = new Bus("Bus Kuning", 50, "Jakarta");
        transportasi[1] = new Kereta("Kereta Merah", 100, "Bandung");
        transportasi[2] = new Pesawat ("Pesawat Biru", 200, "Surabaya");

        for (Transportasi t : transportasi) {
            System.out.println("=== TIKET TRANSPORTASI ===" );
            System.out.println("Nama        ; " + t.getNama());
            System.out.println("Jumlah Kursi: " + t.getJumlahKursi());
            System.out.println("Tujuan      : " + t.getTujuan());
            System.out.println("Harga Tiket : " + t.hitungHargaTiket());
            System.out.println();
        }
        
        System.out.println("=== TIKET BUS ===");
        Bus bus = new Bus("Bus Kuning", 50, "Jakarta");
        System.out.println("Harga Tiket Ekonomi: " + bus.hitungHargaTiket("Ekonomi"));
        System.out.println("Harga Tiket Bisnis : " + bus.hitungHargaTiket("Bisnis"));
        System.out.println("Harga Tiket VIP    : " + bus.hitungHargaTiket("VIP"));
        System.out.println();

        System.out.println("=== TIKET KERETA ===");
        Kereta kereta = new Kereta("Kereta Merah", 100, "Bandung");
        System.out.println("Harga Tiket Ekonomi: " + kereta.hitungHargaTiket("Ekonomi"));
        System.out.println("Harga Tiket Bisnis : " + kereta.hitungHargaTiket("Bisnis"));
        System.out.println("Harga Tiket VIP    : " + kereta.hitungHargaTiket("VIP"));
        System.out.println();

        System.out.println("=== TIKET PESAWAT ===");
        Pesawat pesawat = new Pesawat ("Pesawat Biru", 200, "Surabaya");
        System.out.println("Harga Tiket Ekonomi: " + pesawat.hitungHargaTiket("Ekonomi"));
        System.out.println("Harga Tiket Bisnis : " + pesawat.hitungHargaTiket("Bisnis"));
        System.out.println("Harga Tiket VIP    : " + pesawat.hitungHargaTiket("VIP"));
        System.out.println();
    }
}
