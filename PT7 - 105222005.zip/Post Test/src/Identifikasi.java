class Produk {
    String harga = "Rp. 10.000";
}

class Buku extends Produk {
    String harga = "Rp. 25.000";
    
    void bandingkanHarga(){
        System.out.println("Harga Buku  : " + harga);
        System.out.println("Harga Produk: " + super.harga);
    }
}

public class Identifikasi {
    public static void main(String[] args) throws Exception {
        Buku buku = new Buku();
        buku.bandingkanHarga(); // Memanggil metode bandingkanHarga dari kelas Buku
    }
}
