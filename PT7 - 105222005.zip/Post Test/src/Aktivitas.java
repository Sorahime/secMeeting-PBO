class Orang {
    Orang (){
        System.out.println("Orang dibuat!");
    }
}

class Dosen extends Orang {
    Dosen (){
        super();
        System.out.println("Dosen dibuat!");
    }

}

public class Aktivitas {
    public static void main(String[] args) throws Exception {
        Orang orang = new Orang();   
        Dosen dosen = new Dosen();   
    }
}
