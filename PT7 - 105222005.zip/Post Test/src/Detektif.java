class Bangunan {
    String nama = "Bangunan Umum";

    Bangunan () {
        System.out.println("Konstruktor Bangunan");
    }
}

class GedungSekolah extends Bangunan {
    String nama = "Gedung Sekolah ABC";

    void tampilkanInfo(){
        System.out.println("Nama: " + nama);
        System.out.println("Tipe: " + super.nama);
    }
}

public class Detektif {
    public static void main(String[] args) throws Exception { 
        GedungSekolah gedungSekolah = new GedungSekolah();
        gedungSekolah.tampilkanInfo(); 
    }
}