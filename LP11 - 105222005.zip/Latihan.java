import java.util.Scanner;
import java.util.InputMismatchException;

public class Latihan {

    static class InvalidBookIDException extends Exception {
        public InvalidBookIDException(String message) {
            super(message);
        }
    }

    static class InvalidLoanDurationException extends Exception {
        public InvalidLoanDurationException(String message) {
            super(message);
        }
    }

    public static void main(String[] args) {
        String[] availableBooks = {"B001", "B002", "B003"};
        Scanner scanner = new Scanner(System.in);

        try {
            // Nama pengguna
            System.out.print("Masukkan nama Anda: ");
            String nama = scanner.nextLine();

            // ID buku
            System.out.print("Masukkan ID buku: ");
            String bookId = scanner.nextLine();

            // Validasi ID buku
            boolean validBook = false;
            for (String id : availableBooks) {
                if (id.equals(bookId)) {
                    validBook = true;
                    break;
                }
            }
            
            if (!validBook) {
                throw new InvalidBookIDException(
                    "ID buku tidak valid. Harus salah satu dari: " + 
                    String.join(", ", availableBooks)
                );
            }

            // Durasi peminjaman
            System.out.print("Masukkan lama peminjaman (hari): ");
            int loanDuration;
            try {
                loanDuration = scanner.nextInt();
            } catch (InputMismatchException e) {
                throw new InputMismatchException("Input lama peminjaman harus berupa bilangan bulat.");
            }

            if (loanDuration < 1 || loanDuration > 14) {
                throw new InvalidLoanDurationException("Lama peminjaman harus antara 1 - 14 hari.");
            }

            System.out.println("Peminjaman berhasil untuk " + nama + 
                               ", buku ID: " + bookId + 
                               " selama " + loanDuration + " hari.");

        } catch (InvalidBookIDException | InvalidLoanDurationException e) {
            System.out.println("Exception: " + e.getMessage());

        } catch (InputMismatchException e) {
            System.out.println("Exception: " + e.getMessage());

        } finally {
            scanner.close();
        }
    }
}
