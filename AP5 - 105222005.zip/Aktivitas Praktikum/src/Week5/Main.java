package Week5;

public class Main {
    public static void main (String[]args) {
        Mahasiswa mhs1 = new Mahasiswa("Budi", 21);
        System.out.println(mhs1.getNama());
        System.out.println(mhs1.getUmur());
        mhs1.tampilkanInfo();

        Mahasiswa mhs2 = new Mahasiswa("Susi");
        System.out.println(mhs2.getNama());
    }
}
