package Week5.arrayObject;
import Week5.Mahasiswa;

public class Main {
    public static void main(String[] args) {
    
        Mahasiswa[] student1 = {
            new Mahasiswa("Budi"),
            new Mahasiswa("Susi"),
            new Mahasiswa("Agus")
        };

        System.out.println();

        Mahasiswa[] students2 = {
            new Mahasiswa("Budi", 20),
            new Mahasiswa("Susi", 21),
            new Mahasiswa("Agus", 22)
        };

        for (Mahasiswa mahasiswa : student1) {
            System.out.println(mahasiswa.getNama());
        }

        for (Mahasiswa mahasiswa : students2) {
            System.out.println(mahasiswa.getNama() + " " + mahasiswa.getUmur());
        }

        // // Student[0];
        // Students.

        Mahasiswa[] mhs1 = new Mahasiswa[3];
        mhs1[0] = new Mahasiswa("Budi");
        mhs1[1] = new Mahasiswa("Susi");
        mhs1[2] = new Mahasiswa("Agus");

        Mahasiswa[] mhs2 = new Mahasiswa[3];
        mhs2[0] = new Mahasiswa("Budi", 20);
        mhs2[1] = new Mahasiswa("Susi", 21);
        mhs2[2] = new Mahasiswa("Agus", 22);

    }
}
