package Week5;

public class Mahasiswa {

    // variabel instances
    String nama = "Andi";
    int umur = 20;
    
    public Mahasiswa() {
       
    }

    public Mahasiswa(String nama) {
        this.nama = nama;
    }

    public Mahasiswa (String nama, int umur) {
        this.nama = nama;
        this.umur = umur;
    }

    public void tampilkanInfo() {
        // variabel lokal
        String nama = "Budi";
        System.out.println(nama);
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public int getUmur() {
        return umur;
    }

    public static void main(String[] args) {
    Mahasiswa mhs1 = new Mahasiswa();
    // System.out.println(mhs1.nama);
    // Error: non-static variable nama cannot be referenced from a static context

    mhs1.tampilkanInfo();
    System.out.println(mhs1.nama);
    System.out.println(mhs1.umur);

    Mahasiswa mhs2 = new Mahasiswa("Susi");
    System.out.println(mhs2.nama);
    }
}