package Week5.mypackage;

public class MyClass {
    private int studNum;
    private String classCode;
    private String className;
    private String lecturer;

    public MyClass() {
    }
    
    public MyClass(int studNum, String classCode, String className, String lecturer) {
        this.studNum = studNum;
        this.classCode = classCode;
        this.className = className;
        this.lecturer = lecturer;
    }

    public MyClass(String classCode, String className, String lecturer) {
        this.classCode = classCode;
        this.className = className;
        this.lecturer = lecturer;
    }
        
    public int getStudNum() {
        return studNum;
    }

    public void setStudNum(int studNum) {
        this.studNum = studNum;
    }

    public String getClassCode() {
        return classCode;
}

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getLecturer() {
        return lecturer;
    }

    public void setLecturer(String lecturer) {
        this.lecturer = lecturer;
    }

    public void displayInfo() {
        System.out.println("Nomor Mahasiswa: " + studNum + ", Kode Kelas: " + classCode + ", Nama Kelas: " + className + ", Dosen: " + lecturer);
    }
 
    public void sayHello() {
        System.out.println("Hello from MyClass");
    }

    public void sayHello(String name) {
        System.out.println("Hello " + name);
    }
}
