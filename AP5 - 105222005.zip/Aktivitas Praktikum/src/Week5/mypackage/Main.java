package Week5.mypackage;

import Week5.enkapsulasi.Car;

public class Main {
    public static void main(String[] args) {
        MyClass myC1 = new MyClass();
        myC1.sayHello();

        Car myCar1 = new Car("Toyota", "Avanza", 2020);
        System.out.println(myCar1.getBrand());
        System.out.println(myCar1.getModel());
        System.out.println(myCar1.getPrice());

    }
}