package Week5.enkapsulasi;

public class Main {
    public static void main(String[] args) {

        //Mahasiswa
        Mahasiswa mhs1 = new Mahasiswa("Sora");
        System.out.println("Nama: " + mhs1.getNama());

        Mahasiswa mhs2 = new Mahasiswa(20);
        System.out.println("Umur: " + mhs2.getUmur());

        Mahasiswa mhs3 = new Mahasiswa("Abel", 25);
        System.out.println("Nama: " + mhs3.getNama());
        System.out.println("Umur: " + mhs3.getUmur());

        Mahasiswa mhs4 = new Mahasiswa("Lucien", 18);
        System.out.println("Nama: " + mhs4.getNama() + ", Umur: " + mhs4.getUmur());

        Mahasiswa mhs5 = new Mahasiswa();
        mhs5.setNama("Budi");
        System.out.println("Nama: " + mhs4.getNama());

        // mhs4.setUmur(-20); error
        mhs4.tampilkanInfo(); 

        System.out.println();

        //CAR
        Car myCar1 = new Car();
        System.out.println("Owner: " + myCar1.getOwner());
        System.out.println("Brand: " + myCar1.getBrand());
        System.out.println("Model: " + myCar1.getModel());
        System.out.println("Tires: " + myCar1.getTiresNum());
        System.out.println("Harga: " + myCar1.getPrice());
        myCar1.displayInfo();

        System.out.println();

        Car myCar2 = new Car("Ferrari", "Ferrari 296GTB", 100000000);
        System.out.println("Brand: " + myCar2.getBrand());
        System.out.println("Model: " + myCar2.getModel());
        System.out.println("Harga: " + myCar2.getPrice());

        System.out.println();

        Car myCar3 = new Car("Sora", "Porsche", "Porsche 911 Turbo S", 4, 200000000);
        System.out.println("Owner: " + myCar3.getOwner()); 
        System.out.println("Brand: " + myCar3.getBrand());
        System.out.println("Model: " + myCar3.getModel());
        System.out.println("Tires: " + myCar3.getTiresNum());
        System.out.println("Harga: " + myCar3.getPrice());
        myCar3.displayInfo();

        System.out.println();

    }   

}
