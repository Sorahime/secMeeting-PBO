package Week5.enkapsulasi;

public class Car {
    private String owner;
    private String brand;
    private String model;
    private int tiresNum;
    private int price;

    public Car() {
    }

    public Car(String owner, String brand, String model, int tiresNum, int price) {
        this.owner = owner;
        this.brand = brand;
        this.model = model;
        this.tiresNum = tiresNum;
        this.price = price;
    }

    public Car(String brand, String model, int price) {
        this.brand = brand;
        this.model = model;
        this.price = price;
    }

    public String getOwner() {
        return owner;
    }   

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getTiresNum() {
        return tiresNum;
    }

    public void setTiresNum(int tiresNum) {
        this.tiresNum = tiresNum;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        if (price > 0) {
            this.price = price;
        } else {
            System.out.println("Nilai harga tidak valid");
        }
    }

    public void displayInfo() {
        System.out.println("Merk: " + brand + ", Model: " + model + ", Tahun: " + tiresNum + ", Harga: " + price);
    }
    
}
