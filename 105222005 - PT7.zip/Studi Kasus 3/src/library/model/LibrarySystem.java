package library.model;
import java.util.ArrayList;
import library.main.Book;
import library.main.Member;

public class LibrarySystem {
    
    private ArrayList<Book> books;
    private ArrayList<Member> members;

    public LibrarySystem() {
        books = new ArrayList<>();
        members = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void addMember(Member member) {
        members.add(member);
    }

    public void tampilBuku() {
        System.out.println("Books in the library:");
        for (Book book : books) {
            System.out.println("Title: " + book.getTitle() + ", Author: " + book.getAuthor() + ", Year: " + book.getYearPublished());
        }
        System.out.println();
    }

    public void tampilMember() {
        System.out.println("Members of the library:");
        for (Member member : members) {
            System.out.println("Name: " + member.getName() + ", Member ID: " + member.getMemberId());
        }
        System.out.println();
    }


    public static void main(String[] args) {
        LibrarySystem library = new LibrarySystem();

        // Add book
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "1925");
        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee", "1960");
        library.addBook(book1);
        library.addBook(book2);

        // Add member
        Member member1 = new Member("Sofia", "105222005");
        Member member2 = new Member("Sora", "500222105");
        library.addMember(member1);
        library.addMember(member2);

        System.out.println("WELCOME TO THE LIBRARY SYSTEM");
        System.out.println("===================================");
        System.out.println("Here are the books and members in the library:");
        System.out.println("===================================");

        library.tampilBuku();

        System.out.println("===================================");
        System.out.println("Here are the members in the library:");
        System.out.println("===================================");

        library.tampilMember();

        System.out.println("===================================");
        System.out.println("Thank you for using the library system!");
        System.out.println("===================================");

    }
}

