class PaymentMethod{
    void processPayment(double amount){
        System.out.println("Proses Pembayaran Sebesar $ " + amount);
    }

    void processPayment(double amount, String currency){
        System.out.println("Proses Pembayaran Sebesar $ " + amount + " " + currency);
    }
}

class CreditCard extends PaymentMethod{
    @Override
    void processPayment(double amount){
        System.out.println("Proses Pembayaran Menggunakan Kartu Kredit Sebesar $ " + amount);
    }

    @Override
    void processPayment(double amount, String currency){
        System.out.println("Proses Pembayaran Menggunakan Kartu Kredit Sebesar $ " + amount + " " + currency);
        System.out.println();
    }
}

class EWallet extends PaymentMethod{
    @Override
    void processPayment(double amount){
        System.out.println("Proses Pembayaran Menggunakan E-Wallet Sebesar $ " + amount);
    }

    @Override
    void processPayment(double amount, String currency){
        System.out.println("Proses Pembayaran Menggunakan E-Wallet Sebesar $ " + amount + " " + currency);
        System.out.println();
    }
}

class BankTransfer extends PaymentMethod{
    @Override
    void processPayment(double amount){
        System.out.println("Proses Pembayaran Menggunakan Bank Transfer Sebesar $ " + amount);
    }

    @Override
    void processPayment(double amount, String currency){
        System.out.println("Proses Pembayaran Menggunakan Bank Transfer Sebesar $ " + amount + " " + currency);
        System.out.println();
    }
}

public class SistemPembayaran {
    public static void main(String[] args) throws Exception {
        PaymentMethod a1 = new CreditCard(); 
        a1.processPayment(10000);
        a1.processPayment(50000, "USD");

        PaymentMethod a2 = new EWallet();
        a2.processPayment(3000);
        a2.processPayment(20000, "IDR");

        PaymentMethod a3 = new BankTransfer();
        a3.processPayment(500000);
        a3.processPayment(1000000, "EUR");
    }
}
