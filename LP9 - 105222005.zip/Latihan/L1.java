package Latihan;

class Animal {
    HealthRecord rekamMedis;

    Animal (HealthRecord healthRecord) {
        this.rekamMedis = healthRecord;
    }

    void makeSound() {
        System.out.println("Aku Denger Suara");
    }
}


class Dog extends Animal {
    Dog (HealthRecord healthRecord) {
        super (healthRecord);
    } @Override
    void makeSound() {
        System.out.println("Guk-guk!");
    }
}

class Cat extends Animal {
    Cat(HealthRecord healthRecord) {
        super (healthRecord);
    } @Override
    void makeSound() {
        System.out.println("Meow!");
    }
}

class HealthRecord {
    private String noRekamMedis;
    private String tanggalRekamMedis;

    public HealthRecord(String noRekamMedis, String tanggalRekamMedis) {
        this.noRekamMedis = noRekamMedis;
        this.tanggalRekamMedis = tanggalRekamMedis;
    }

    public String getNoRekamMedis() {
        return noRekamMedis;
    }

    public String getTanggalRekamMedis() {
        return tanggalRekamMedis;
    }
}

class Owner  {
    private String nama;
    private Animal hewanPeliharaan;

    public Owner(String nama, Animal hewanPeliharaan) {
        this.nama = nama;
        this.hewanPeliharaan = hewanPeliharaan;
    }

    public void tampilkanHewanPeliharaan() {
        System.out.println("Nama Pemilik    : " + nama);

        if (hewanPeliharaan instanceof Dog) {
            System.out.println("Hewan Peliharaan adalah Anjing");
        } else if (hewanPeliharaan instanceof Cat) {
            System.out.println("Hewan Peliharaan adalah Kucing");
        }
        System.out.print("Suara Hewan Peliharaan: ");
        hewanPeliharaan.makeSound();

        System.out.println("No Rekam Medis        : " + hewanPeliharaan.rekamMedis.getNoRekamMedis());
        System.out.println("Tanggal Rekam Medis   : " + hewanPeliharaan.rekamMedis.getTanggalRekamMedis());
        System.out.println();
    }
}

public class L1 {
    public static void main(String[] args) {
      
        HealthRecord rekamMedis1 = new HealthRecord("12345", "2023-10-01");
        Animal dog1 = new Dog(rekamMedis1);
        Owner pemilik1 = new Owner("Sora", dog1);
        pemilik1.tampilkanHewanPeliharaan();

        HealthRecord rekamMedis2 = new HealthRecord("67890", "2023-10-02");
        Animal cat1 = new Cat(rekamMedis2);
        Owner pemilik2 = new Owner("Sofia", cat1);
        pemilik2.tampilkanHewanPeliharaan();
    }
}
