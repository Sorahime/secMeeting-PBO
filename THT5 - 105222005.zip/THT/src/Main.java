import librarysystem.*;

public class Main {
    public static void main(String[] args) {
        Perpustakaan perpustakaan = new Perpustakaan(5);

        Buku buku1 = new Buku("The Art of War", "Sun Tzu", "Abad ke-5 SM");
        Buku buku2 = new Buku("On War", "Carl von Clausewitz", "1832");
        Buku buku3 = new Buku("The Face of Battle", "John Keegan", "1976");
        Buku buku4 = new Buku("Black Hawk Down", "Mark Bowden", "1999");
        Buku buku5 = new Buku("The Accidental Guerrilla", "David Kilcullen", "2009");

        perpustakaan.tambahBuku(buku1);
        perpustakaan.tambahBuku(buku2);
        perpustakaan.tambahBuku(buku3);
        perpustakaan.tambahBuku(buku4);
        perpustakaan.tambahBuku(buku5);
        System.out.println();

        System.out.println ("========= DAFTAR BUKU =========");
        perpustakaan.tampilkanBuku();

        System.out.println ("====== PROSES PEMINJAMAN ======");
        user user1 = new user("Sora", 101);
        user1.pinjamBuku(buku1);
        perpustakaan.tampilkanBuku();

        user user2 = new user ("Sofia", 105);
        user2.pinjamBuku(buku1);
        
        System.out.println ("===== PROSES PENGEMBALIAN =====");
        user1.kembalikanBuku(buku1);
        perpustakaan.tampilkanBuku();

        System.out.println ("====== PROSES PEMINJAMAN ======");
        user2.pinjamBuku(buku1);
    }
}

