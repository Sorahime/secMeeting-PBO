package librarysystem;


public class Perpustakaan {
    private Buku[] koleksiBuku;
    private int jumlahBuku;

    public Perpustakaan(int kapasitas) {
        koleksiBuku = new Buku[kapasitas]; // Ukuran tetap
        jumlahBuku = 0;
    }

    public void tambahBuku(Buku buku) {
        if (jumlahBuku < koleksiBuku.length) {
            koleksiBuku[jumlahBuku] = buku;
            jumlahBuku++;
            System.out.println("Buku " + buku.getJudul() + " ditambahkan ke perpustakaan.");
        } else {
            System.out.println("Perpustakaan penuh, tidak bisa menambah buku lagi.");
        }
    }

    public void tampilkanBuku(){
        for (Buku buku : koleksiBuku) {
            System.out.println ("Judul    : " + buku.getJudul());
            System.out.println ("Penulis  : " + buku.getPenulis());
            System.out.println ("Tahun    : " + buku.getTahunTerbit());
            System.out.println ("Dipinjam : " + buku.isStatusDipinjam());
            System.out.println();
        }
    }
}