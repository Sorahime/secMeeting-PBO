package librarysystem;

public class user {
    private String nama;
    private int idUser;

    public user (String nama, int idUser){
        this.nama = nama;
        this.idUser = idUser;
    }
    
    //Method
    public void pinjamBuku (Buku buku){
        if (!buku.isStatusDipinjam()){
            buku.pinjamBuku();
            System.out.println (nama + " dengan ID " + idUser + " meminjam buku: " + buku.getJudul());
            System.out.println();
        } else {
            System.out.println ("Buku : " + buku.getJudul() + " sedang dipinjam oleh pembaca lain");
            System.out.println();
        }
    }

    public void kembalikanBuku (Buku buku) {
        buku.kembalikanBuku();
        System.out.println(nama + " dengan ID " + idUser + " mengembalikan buku " + buku.getJudul());
        System.out.println();
    }

}
