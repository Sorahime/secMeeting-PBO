package librarysystem;

public class Buku {
    private String judul;
    private String penulis;
    private String tahunTerbit;
    private boolean statusDipinjam;
    private static int jumlahBukuTersedia;

    //Konstruktor
    public Buku (String judul, String penulis, String tahunTerbit) {
        this.judul = judul;
        this.penulis = penulis;
        this.tahunTerbit = tahunTerbit;
        this.statusDipinjam = false;
        jumlahBukuTersedia++;
    }

    //Getter
    public String getJudul(){
        return judul;
    }
    
    public String getPenulis(){
        return penulis;
    }

    public String getTahunTerbit(){
        return tahunTerbit;
    }

    public boolean isStatusDipinjam(){
        return statusDipinjam;
    }

    //Setter
    public void setJudul(String judul){
        this.judul = judul;
    }

    public void setPenulis(String penulis){
        this.penulis = penulis;
    }

    public void setTahunTerbit(String tahunTerbit){
        this.tahunTerbit = tahunTerbit;
    }

    public void setStatusDipinjam(Boolean statusDipinjam){
        this.statusDipinjam = statusDipinjam;
    }

    //Statis
    public static int getJumlahBukuTersedia(){
        return jumlahBukuTersedia;
    }

    // Method
    public void pinjamBuku(){
        if (!statusDipinjam) {
            statusDipinjam = true;
            jumlahBukuTersedia--;
            System.out.println(judul + " telah dipinjam.");
        } else{
            System.out.println(judul + " sedang dipinjam.");
        }
    }

    public void kembalikanBuku(){
        if (statusDipinjam){
            statusDipinjam = false;
            jumlahBukuTersedia++;
            System.out.println(judul + " telah dikembalikan.");
        }
    }

}