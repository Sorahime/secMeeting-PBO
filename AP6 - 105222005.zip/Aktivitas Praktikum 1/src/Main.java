import dosen.Dosen;
import mahasiswa.Mahasiswa;
import mataKuliah.MataKuliah;
import java.util.ArrayList;

public class Main{
    public static void main(String[] args) throws Exception {
        Dosen dosen1 = new Dosen("Dr. Cahya", "1234567890"); 
        Dosen dosen2 = new Dosen("Dr. Siti", "0987654321");

        Mahasiswa mahasiswa1 = new Mahasiswa("Tiara", "105222001");
        Mahasiswa mahasiswa2 = new Mahasiswa("Diana", "105222002");

        ArrayList<Mahasiswa> daftarMahasiswa1 = new ArrayList<>();
        daftarMahasiswa1.add(mahasiswa1);
        daftarMahasiswa1.add(mahasiswa2);

        ArrayList<Mahasiswa> daftarMahasiswa2 = new ArrayList<>();
        daftarMahasiswa2.add(mahasiswa1);

        ArrayList<Dosen> daftarDosen1 = new ArrayList<>();
        daftarDosen1.add(dosen1);

        ArrayList<Dosen> daftarDosen2 = new ArrayList<>();
        daftarDosen2.add(dosen2);

        MataKuliah mataKuliah1 = new MataKuliah("Pemrograman Berorientasi Objek", "CS123");
        mataKuliah1.setPengampu(daftarDosen1);
        mataKuliah1.setDaftarMahasiswa(daftarMahasiswa1);

        MataKuliah mataKuliah2 = new MataKuliah("Komputasi Pararel", "CS124");
        mataKuliah2.setPengampu(daftarDosen2);
        mataKuliah2.setDaftarMahasiswa(daftarMahasiswa1);

        MataKuliah mataKuliah3 = new MataKuliah("Metode Numerik", "CS125");
        mataKuliah3.setPengampu(daftarDosen2);
        mataKuliah3.setDaftarMahasiswa(daftarMahasiswa2);
    }

    public static void tampilkanData(MataKuliah mataKuliah) {
        System.out.println("Mata Kuliah: " + mataKuliah.getNama());
        System.out.println("Kode MK: " + mataKuliah.getKodeMK());
        System.out.print("Dosen Pengampu: ");
        for (Dosen dosen : mataKuliah.getPengampu()) {
            System.out.print(dosen.getNama() + " ");
        }System.out.println();
        
        System.out.println("Daftar Mahasiswa: ");
        for (Mahasiswa mhs : mataKuliah.getDaftarMahasiswa()) {
            System.out.println("- " + mhs.getNama() + " (" + mhs.getNIM() + ")");
        } System.out.println();
    }
}
